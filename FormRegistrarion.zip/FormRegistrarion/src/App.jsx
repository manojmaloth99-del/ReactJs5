import React from 'react'
import FormRegistration from './FormRegistration'

export default function App() {
  return (
    <div>
      <FormRegistration/>
    </div>
  )
}
