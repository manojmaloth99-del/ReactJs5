
import React, { useState } from 'react'
import './FormRegistration.css'

const initialData = {
    firstName: "",
    lastName: "",
    email: "",
    mobile: "",
    password: "",
    confirmPassword: "",
    dob: "",
    gender: "",
    address: "",
    city: ""
}

export default function FormRegistration() {

    const [formData, setFormData] = useState(initialData)
    const [error, setError] = useState({})
    const [success, setSuccess] = useState("")

    
    const handleChange = (e) => {
        const { name, value } = e.target

        setFormData((prevData) => ({
            ...prevData,
            [name]: value
        }))

        setError((prevError) => ({
            ...prevError,
            [name]: ""
        }))

        setSuccess("")
    }

    
    const validateForm = () => {

        let newErrors = {}

        if (!formData.firstName.trim()) {
            newErrors.firstName = "First name is required"
        }

        if (!formData.lastName.trim()) {
            newErrors.lastName = "Last name is required"
        }

        if (!formData.email.trim()) {
            newErrors.email = "Email is required"
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
            newErrors.email = "Enter a valid email"
        }

        if (!/^[0-9]{10}$/.test(formData.mobile)) {
            newErrors.mobile = "Enter a valid 10 digit number"
        }

        if (formData.password.length < 8) {
            newErrors.password = "Password must contain at least 8 characters"
        }

        if (!formData.confirmPassword) {
            newErrors.confirmPassword = "Confirm password is required"
        } else if (formData.confirmPassword !== formData.password) {
            newErrors.confirmPassword = "Passwords do not match"
        }

        if (!formData.dob) {
            newErrors.dob = "Date of birth is required"
        } else if (new Date(formData.dob) > new Date()) {
            newErrors.dob = "Date of birth cannot be in the future"
        }

        if (!formData.gender) {
            newErrors.gender = "Please select gender"
        }

        if (!formData.address.trim()) {
            newErrors.address = "Address is required"
        }

        if (!formData.city.trim()) {
            newErrors.city = "City is required"
        }

        setError(newErrors)

        return Object.keys(newErrors).length === 0
    }

    
    const handleSubmit = (e) => {
        e.preventDefault()

        if (validateForm()) {

            console.log("Registration Details:", formData)

            setSuccess("Registration Successful!")

            setFormData({ ...initialData })
        }
    }

    
    const handleReset = () => {
        setFormData({ ...initialData })
        setError({})
        setSuccess("")
    }

    return (
        <div className="registration-container">

            <form
                className="registration-form"
                onSubmit={handleSubmit}
                noValidate
            >

                <h1>Registration Form</h1>

                <table>
                    <tbody>

                        <tr>
                            <td>First Name:</td>
                            <td>
                                <input
                                    type="text"
                                    name="firstName"
                                    value={formData.firstName}
                                    onChange={handleChange}
                                    placeholder="Enter First Name"
                                />
                                <p className="error-message">{error.firstName}</p>
                            </td>
                        </tr>

                        <tr>
                            <td>Last Name:</td>
                            <td>
                                <input
                                    type="text"
                                    name="lastName"
                                    value={formData.lastName}
                                    onChange={handleChange}
                                    placeholder="Enter Last Name"
                                />
                                <p className="error-message">{error.lastName}</p>
                            </td>
                        </tr>

                        <tr>
                            <td>Email:</td>
                            <td>
                                <input
                                    type="email"
                                    name="email"
                                    value={formData.email}
                                    onChange={handleChange}
                                    placeholder="Enter Email"
                                />
                                <p className="error-message">{error.email}</p>
                            </td>
                        </tr>

                        <tr>
                            <td>Mobile Number:</td>
                            <td>
                                <input
                                    type="tel"
                                    name="mobile"
                                    value={formData.mobile}
                                    onChange={handleChange}
                                    placeholder="Enter Mobile Number"
                                />
                                <p className="error-message">{error.mobile}</p>
                            </td>
                        </tr>

                        <tr>
                            <td>Password:</td>
                            <td>
                                <input
                                    type="password"
                                    name="password"
                                    value={formData.password}
                                    onChange={handleChange}
                                    placeholder="Enter Password"
                                />
                                <p className="error-message">{error.password}</p>
                            </td>
                        </tr>

                        <tr>
                            <td>Confirm Password:</td>
                            <td>
                                <input
                                    type="password"
                                    name="confirmPassword"
                                    value={formData.confirmPassword}
                                    onChange={handleChange}
                                    placeholder="Confirm Password"
                                />
                                <p className="error-message">{error.confirmPassword}</p>
                            </td>
                        </tr>

                        <tr>
                            <td>Date of Birth:</td>
                            <td>
                                <input
                                    type="date"
                                    name="dob"
                                    value={formData.dob}
                                    onChange={handleChange}
                                />
                                <p className="error-message">{error.dob}</p>
                            </td>
                        </tr>

                        <tr>
                            <td>Gender:</td>
                            <td>
                                <select
                                    name="gender"
                                    value={formData.gender}
                                    onChange={handleChange}
                                >
                                    <option value="">Select Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                                </select>
                                <p className="error-message">{error.gender}</p>
                            </td>
                        </tr>

                        <tr>
                            <td>Address:</td>
                            <td>
                                <textarea
                                    name="address"
                                    value={formData.address}
                                    onChange={handleChange}
                                    placeholder="Enter Address"
                                />
                                <p className="error-message">{error.address}</p>
                            </td>
                        </tr>

                        <tr>
                            <td>City:</td>
                            <td>
                                <input
                                    type="text"
                                    name="city"
                                    value={formData.city}
                                    onChange={handleChange}
                                    placeholder="Enter City"
                                />
                                <p className="error-message">{error.city}</p>
                            </td>
                        </tr>

                        <tr>
                            <td colSpan="2">
                                <button type="submit">
                                    Register
                                </button>

                                <button type="button" onClick={handleReset}>
                                    Reset
                                </button>
                            </td>
                        </tr>

                    </tbody>
                </table>

                {success && (
                    <h3 className="success-message">
                        {success}
                    </h3>
                )}

            </form>
        </div>
    )
}
